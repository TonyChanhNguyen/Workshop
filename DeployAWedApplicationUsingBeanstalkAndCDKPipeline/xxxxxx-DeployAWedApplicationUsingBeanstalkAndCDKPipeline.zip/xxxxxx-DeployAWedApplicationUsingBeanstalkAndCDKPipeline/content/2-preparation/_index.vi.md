---
title : "Các bước chuẩn bị"
date :  "`r Sys.Date()`" 
weight : 2 
chapter : false
pre : " <b> 2. </b> "
---

### Tổng quan

Trước khi bắt đầu bài thực hành này, chúng ta cần tạo:
 + Một GitHub repository để lưu trữ ứng dụng và cơ sở hạ tầng bằng code.
 + Một môi trường phát triển code

### Nội dung
2.1 [Tạo  GitHub Repository](2.1-createrepo/).

2.2 [Chuẩn bị môi trường](2.2-setupenv/).